function love.conf(t)
    t.console = true
    
    t.window.title = 'LineRun Engine'
    t.window.icon = 'LineRun Icon.png'
end