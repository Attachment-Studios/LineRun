-- main.lua

--- SYSTEM-MODULES ---
require 'CI'
require 'is'

--- COMMAND-MODULES ---
require 'log'

--- GENERAL-MODULES ---
require 'UI'

--- ENGINE-WORKING ---
function love.load()
    system = {}
    system.version = 'V0.0.1_5'
    print(' _     _  ___     _  _______ ')
    print('| |   | ||   \\   | ||  _____|')
    print('| |   | || |\\ \\  | || |_____ ')
    print('| |   | || | \\ \\ | ||  _____|')
    print('| |__ | || |  \\ \\| || |_____ ')
    print('|____||_||_|   \\___||_______|')
end

function love.draw()
    ui.draw()
end

function love.filedropped(f)
    f:open('r')
    local filedata = f:read()
    local t = {}
    love.filesystem.write('code-engine-last-dropped-file.txt', filedata)
    for line in love.filesystem.lines('code-engine-last-dropped-file.txt') do
        table.insert(t, line)
    end
    for i = 1, #t do
        t[i] = is.comment(t[i])
    end
    for i = 1, #t do
        log.actionCheck(t[i], i)
    end
    f:close()
end

