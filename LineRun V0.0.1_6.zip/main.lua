-- main.lua

--- SYSTEM-MODULES ---
require ('system')
require (system.vcode..'.CI')
require (system.vcode..'.is')

--- COMMAND-MODULES ---
require (system.vcode..'.log')
require (system.vcode..'.var')

--- GENERAL-MODULES ---
require (system.vcode..'.UI')

--- ENGINE-START-UP ---
function love.load()
    print(' _________________________________________________________       ')
    print('| _     _  ___     _  _______  _____  _      _  ___     _ |      ')
    print('|| |   | ||   \\   | ||  _____||  _  || |    | ||   \\   | ||    ')
    print('|| |   | || |\\ \\  | || |_____ | |_| || |    | || |\\ \\  | ||  ')
    print('|| |   | || | \\ \\ | ||  _____||    _|| |    | || | \\ \\ | ||  ')
    print('|| |__ | || |  \\ \\| || |_____ | |\\ \\ | |____| || |  \\ \\| ||')
    print('||____||_||_|   \\___||_______||_| \\_\\|________||_|   \\___||  ')
    print('|_________________________________________________________|      ')
end

--- ENGINE-DISPLAY ---
function love.draw()
    ui.draw()
end

--- ENGINE-WORKING ---
function love.filedropped(f)
    f:open('r')
    local filename = f:getFilename()
    local fileextension = ''
    for i = 0, #filename do
        if string.getCharacter(filename, #filename-i) == '.' then
            break
        else
            fileextension = string.getCharacter(filename, #filename-i)..fileextension
        end
    end

    local filedata = f:read()
    if fileextension == 'linecode' or fileextension == 'a45' then
        local t = {}
        love.filesystem.write('code-engine-last-dropped-file.txt', filedata)
        for line in love.filesystem.lines('code-engine-last-dropped-file.txt') do
            table.insert(t, line)
        end
        for i = 1, #t do
            t[i] = is.comment(t[i])
        end
        for i = 1, #t do
            log.actionCheck(t[i], i)
            var.actionCheck(t[i], i)
        end
    else
        print('Error:')
        print('    Invalid file format "'..fileextension..'"')
    end
    f:close()
end

