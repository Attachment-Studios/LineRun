system = {}
system.version = "V0.0.1_7"
system.vcode = "V001.7"

function system.readFile(f)
    f:open('r')
    local filename = f:getFilename()
    local fileextension = ''
    for i = 0, #filename do
        if string.getCharacter(filename, #filename-i) == '.' then
            break
        else
            fileextension = string.getCharacter(filename, #filename-i)..fileextension
        end
    end

    local filedata = f:read()
    if fileextension == 'linecode' or fileextension == 'a45' then
        local t = {}
        love.filesystem.write('code.linecode', filedata)
        for line in love.filesystem.lines('code.linecode') do
            table.insert(t, line)
        end
        for i = 1, #t do
            t[i] = is.comment(t[i])
        end
        for i = 1, #t do
            log.actionCheck(t[i], i)
            var.actionCheck(t[i], i)
        end
    else
        print('Error:')
        print('    Invalid file format "'..fileextension..'"')
    end
    f:close()
end