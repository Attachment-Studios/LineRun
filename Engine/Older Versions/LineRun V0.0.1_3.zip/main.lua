-- main.lua

--- SYSTEM-MODULES ---
require 'CI'
require 'is'

--- COMMAND-MODULES ---
require 'log'

--- ENGINE-WORKING ---
function love.filedropped(f)
    f:open('r')
    local filedata = f:read()
    local t = {}
    love.filesystem.write('code-engine-last-dropped-file.txt', filedata)
    for line in love.filesystem.lines('code-engine-last-dropped-file.txt') do
        table.insert(t, line)
    end
    for i = 1, #t do
        t[i] = is.comment(t[i])
    end
    for i = 1, #t do
        if t[i] ~= '' then
            print(t[i])
        end
    end
    for i = 1, #t do
        log.actionCheck(t[i], i)
    end
    f:close()
end

