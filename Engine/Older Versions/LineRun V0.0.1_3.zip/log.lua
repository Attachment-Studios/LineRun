-- log module

require 'is'

log = {}

--- FUNCTIONS ---
function log.test()
    print('tested!')
end

--- ACTION-CHECKS ---
function log.actionCheck(command, line)
    if is.module(command) == 'log' then
        local fragment = is.moduleFragment(command)
        if fragment == 'test' then
            log.test()
        else
            print('error in line '..line..':')
            if fragment ~= '' then
                print('    Unknown Fragment')
            else
                print('    No Fragment Given')
            end
        end
    end
end

