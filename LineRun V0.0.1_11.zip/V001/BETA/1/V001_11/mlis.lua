-- multi-line iteration system.lua

require "system"
require(system.vcode..".CI")
require(system.vcode..".is")

mlis = {}
mlis.activeTable = {}

local dir = 'cache/main/mlis'

if not(love.filesystem.getInfo(dir)) then
	love.filesystem.createDirectory(dir)
end

function mlis.comment(fileInTable)
	lineTable = fileInTable
	local fileInLine = ''
	for i = 1, #lineTable do
		local l = lineTable[i]
		fileInLine =  fileInLine..l.."\n"
	end
	local cl = ""
	local mlc = false
	for i =  1, #fileInLine-3 do
		if mlc == false then
			if string.getCharacter(fileInLine, i) == '-' then
				if string.getCharacter(fileInLine, i+1) == '-' then
					if string.getCharacter(fileInLine, i+2) == '>' then
						if string.getCharacter(fileInLine, i+3) == '#' then
							mlc = true
						end
					end
				end
			else
				cl = cl..string.getCharacter(fileInLine, i)
			end
		elseif mlc ==  true then
			if string.getCharacter(fileInLine, i) == '#' then
				if string.getCharacter(fileInLine, i+1) == '<' then
					if string.getCharacter(fileInLine, i+2) == '-' then
						if string.getCharacter(fileInLine, i+3) == '-' then
							mlc = false
						end
					end
				end
			end
		end
	end
	fileInLine = cl
	local lines = {}
	local focus = ''
	for i = 1, #fileInLine do
		local s = function(n) return string.getCharacter(fileInLine, n) end
		if s(i) == '\n' then
			table.insert(lines, focus)
			focus = ''
		else
			focus = focus..s(i)
		end
	end
	return unpack(lines)
end

function mlis.doCode(filename)
    local t = {}
    for line in love.filesystem.lines(filename) do
        table.insert(t, line)
    end
    t = {mlis.comment(t)}
    for i = 1, #t do
        t[i] = is.comment(t[i])
    end
    for i = 1, #t do
        system.moduleCheck(t[i], i)
    end
end

function mlis.replica(n)
	for i = 1, n do
		mlis.doCode(dir.."/replica.linecode")
	end
end

--[[function mlis.check(cmd, line)
	local m = is.module(cmd)
	local f = is.moduleFragment(cmd)
	local arg = {is.argument(cmd)}
	if m == "mlis" then
		if f ~= nil or f ~= '' then
			m = f
		else
			print("error in line "..line..":")
			print("    No fragment exists")
		end
	end
	if m == "###" then
		if #mlis.activeTable == 0 or #mlis.activeTable == nil then
			print('error in line '..line..':')
			print('    ending something that doesn\'t exists')
		end
		if mlis.activeTable[#mlis.activeTable] == 'replica' then
			mlis.replica(arg[1])
			table.remove(mlis.activeTable, #mlis.activeTable)
			love.filesystem.remove(dir.."/replica.linecode")
		end
	end
	if #mlis.activeTable ~= 0 or #mlis.activeTable ~= nil then
		if mlis.activeTable[#mlis.activeTable] == 'replica' then
			if love.filesystem.getInfo(dir.."/replica.linecode") then
				love.filesystem.append(dir.."/replica.linecode", cmd)
			end
		end
	end
	for i = 1, #cmd do
		if string.getCharacter(cmd, i) == ':' then
			if m == 'replica' then
				table.insert(mlis.activeTable, "replica")
			end
			break
		end
	end
end]]

